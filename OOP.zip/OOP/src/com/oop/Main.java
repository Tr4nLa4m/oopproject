package com.oop;

public class Main {

    public static void main(String[] args) {
        Game game = new Game("Tile Game!", 640, 480);
        game.start();
    }
}

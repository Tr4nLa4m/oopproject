package com.oop.tiles;

import com.oop.gfx.Assets;

public class DirtTile extends Tile {

    public DirtTile(int id) {
        super(Assets.dirt, id);
    }

}
package com.oop.tiles;

import com.oop.gfx.Assets;

public class GrassTile extends Tile {

    public GrassTile(int id) {
        super(Assets.grass, id);
    }

}
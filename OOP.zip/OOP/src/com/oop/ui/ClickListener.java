package com.oop.ui;

public interface ClickListener {

    public void onClick();

}